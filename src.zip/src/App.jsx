import React, { useState ,useEffect ,createContext } from 'react';
import ProductBox from './ProductBox';
import NavBar from './NavBar';
import NotFound from './NotFound';
import Footer from './Footer';
import ProductDetail from './ProductDetail';
import { Routes, Route } from 'react-router-dom';
import CartPage from './CartPage';
import SignUpPage from './SignUpPage';
import LoginPage from './LoginPage';
import LinkBar from './LinkBar';
import ForgotPassword from './ForgotPassword';
import { HiMenu } from 'react-icons/hi';
import AuthRoute from './AuthRoute';
import UserRoute from './UserRoute';
import axios from 'axios';
import Loading from './Loading';


export const userDetailContext = createContext();

function App() {

  const saveDataString = localStorage.getItem('my-cart') || '{}';

  const saveData = JSON.parse(saveDataString);

  const [cart, setCart] = useState(saveData);
  const [isMenu, setIsMenu] = useState(false);
  const [userLoading, setUserLoading] = useState(true);
  const [user, setUser] = useState();
  const userData = { user, setUser }
  const token = localStorage.getItem("token");
  useEffect(() => {
    if (token) {
      axios.get("https://myeasykart.codeyogi.io/me", {
        headers: {
          Authorization: token,
        }
        ,
      }).then((response) => {
        setUser(response.data);
        setUserLoading(false);
      })
    } else {
      setUserLoading(true);
    }
    
  }, []);
  if (userLoading) {
     return <Loading/>
   }

  function handleMenuChange() {
    console.log("status changed", isMenu);
    setIsMenu(!isMenu);
  }
  function handleAddToCart(productId, count) {
    console.log('productId', productId, 'count', count);
    const oldCount = cart[productId] || 0;
    const newCart = { ...cart, [productId]: oldCount + count }
    updateCart(newCart);
  }

  function updateCart(newCart) {
    setCart(newCart)
    const cartString = JSON.stringify(newCart);
		localStorage.setItem('my-cart', cartString);
  }

  const totalCount = Object.keys(cart).reduce(function(previous, current) {
    return previous + cart[current];
  }, 0); 

  return (
    <>
      <NavBar productCount={totalCount} />
      <HiMenu onClick={handleMenuChange} className="md:hidden" />
      
      {isMenu && <LinkBar />}
      <div className="flex flex-col h-screen overflow-y-scroll relative">
        <div className='hidden md:block p-4 bg-gray-400'><userDetailContext.Provider value={userData}><LinkBar/></userDetailContext.Provider></div>

        <div className=" grow bg-secondary-default">
          <Routes>
            <Route index element={<UserRoute><ProductBox /></UserRoute>} />
            <Route
              path="/products/:id/"
              element={<ProductDetail onAddToCart={handleAddToCart} />}
            />
            <Route path="*" element={<NotFound />} />
            <Route path='/cart/' element={<UserRoute><CartPage cart={cart} updateCart={updateCart} /></UserRoute>} />
            <Route path="/signup/" element={<userDetailContext.Provider value={userData}><SignUpPage /></userDetailContext.Provider>} />
            <Route path='/login/' element={<userDetailContext.Provider value={userData}><AuthRoute><LoginPage/></AuthRoute></userDetailContext.Provider>}/>
              <Route path='/forgot/' element={<userDetailContext.Provider value={userData}><ForgotPassword /></userDetailContext.Provider>} />
              
          </Routes>
        </div>
      </div>
      <Footer />
    </>
  );
}

export default App;
