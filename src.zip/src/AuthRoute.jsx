import React from 'react';
import { useContext } from 'react';
import { Navigate } from 'react-router-dom';
import { userDetailContext } from './App';


function AuthRoute({children }) {
    const { user } = useContext(userDetailContext);
    
    if (user) {
        <Navigate to="/"/>;
    }

    return children;

}

export default AuthRoute;
