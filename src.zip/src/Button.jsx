import React from 'react';


function Button({children}){
  return(
    <div> 
      <button className="text-2xl font-bold px-5 py-3 text-white bg-primary-default hover:bg-primary-dark">{children}</button>
  </div>
 ); 

}

export default Button;
