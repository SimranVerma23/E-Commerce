import React from 'react';
import {Link} from "react-router-dom";
import { withFormik} from "formik";
import * as Yup from 'yup';
import Input from './Input';
import { useContext } from 'react';
import { userDetailContext } from './App';


function callSignupApi(values ,bag) {

  const { setUser } = useContext(userDetailContext);
    
  axios.post("https://myeasykart.codeyogi.io/signup", {
      username:values.username,
      email: values.email,
      password: values.password
    }).then((response) => {
      console.log("response login api", response.data);

      const { user, token } = response.data
      localStorage.setItem("token", token);
      bag.setUser(user);

    }).catch(() => {
      console.log("inValid credentials");
    }) 
}


   const schema =  Yup.object().shape({
     username:Yup.string().required(),
     email:Yup.string().email('Invalid email').required(),
     password:Yup.string().min(8).required(),
   })
   
   const initialValues={
      username :"",
      password:"",
      email:"",

    }

 export function SignUpPage({values,errors, handleSubmit, handleChange,handleBlur,touched}){
  return(
    <div className='flex flex-col mx-auto max-w-6xl bg-white p-10 sm:p-20 m-20'>
      <h1 className='text-4xl font-bold mb-4 text-gray-600'>Sign Up</h1>
      <form className=" flex flex-col border-2 border-gray-200 p-5 rounded-md">
        <Input onChange={handleChange} onBlur={handleBlur} values={values.username} error={errors.username} touched={touched.username} id='user-name' name='username' type='text' label="User Name" required/>
        <Input onChange={handleChange} onBlur={handleBlur} values={values.email} error={errors.email} touched={touched.email} id='email' name='email' type='email' label="Email" required />
        <Input onChange={handleChange} onBlur={handleBlur} values={values.password} error={errors.password} touched={touched.password} id='password' name='password' type='password' label="Password" required/>
        <Input error={errors.password} touched={touched.password} label="Conform Password" id='conform-password' name='password' type='password' required/>
          <div>
         <button className='text-2xl text-white bg-primary-default rounded-md py-4 px-8 mb-2' type='submit'>Submit</button>
         <button className='text-2xl text-white bg-green-400 rounded-md py-4 px-8 mb-2 ml-2'>Reset Form</button>

         </div>
        <h1 className='text-xl text-gray-600 text-semibold'>Alread have an account?<Link className='text-blue-400 text-xl text-semibold' to="/login/">Login</Link></h1>
        </form>
    

    </div>
 );

}
const myHoc = withFormik({ handleSubmit: callSignupApi, validationSchema: schema, initialValues: initialValues })
const mySignUp = myHoc(SignUpPage);
export default mySignUp;