import React from 'react';


function NoMatching(){
  return(
    <div className="p-20 bg-green-400 border border-2 border-green-800 text-3xl font-bold rounded-xl">No Matching Product</div>
 ); 

}

export default NoMatching;
