import React from 'react';


function Footer(){
  return(
    <div className="p-10 bg-gray-800"> 
<div className=" flex flex-col items-center mx-auto  sm:flex-row sm:justify-between max-w-6xl">
<p className="text-white">Copyright © 2022 | TryCasuals</p>
<p className="text-white">Powered By TryCasuals</p>
</div>
  </div>
 ); 

}

export default Footer;
