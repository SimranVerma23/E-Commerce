import React from 'react';
import DropDown from "./DropDown"

function Header(){
  return(
<div className="flex flex-col items-center sm:flex-row sm:justify-between p-10 bg-white rounded-t-md">
  <h1 className="text-5xl text-red-500 mb-4 sm:mb-0">Shop</h1>
 <DropDown/>
</div>
 ); 

}

export default Header;





